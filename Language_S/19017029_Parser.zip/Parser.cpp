#include "Parser.h"
#include <iostream>

int Parser::getToken()
{
	int ch = NONE;

	while (true)
	{
		ch = input[pos++];

		if (ch == ' ' || ch == '\t' || ch == '\r')	//	���� ���� ���� ��� ���� ��ū Ȯ��
			continue;

		else if (isdigit(ch))
		{
			tokType = DIGIT;
			return ch;
		}

		//	������ ��� -> ����� Ȥ�� ������ ���
		else if (isalpha(ch))
		{
			tokType = CHAR;
			return ch;
		}
		
		else
		{
			switch (ch)
			{
			case '+':
				tokType = ADD;
				return ch;
			case '-':
				tokType = MIN;
				return ch;
			case '*':
				tokType = MUL;
				return ch;
			case '/':
				tokType = DIV;
				return ch;
			case '&':
				tokType = AND;
				return ch;
			case '|':
				tokType = OR;
				return ch;
			case '!':
				tokType = NOT;
				return ch;
			case '<':
				tokType = LESSTHAN;
				return ch;
			case '>':
				tokType = MORETHAN;
				return ch;
			case '=':
				tokType = EQUAL;
				return ch;
			case '(':
				tokType = LPAREN;
				return ch;
			case ')':
				tokType = LPAREN;
				return ch;
			default:
				return NONE;
			}
		}
	}

	return NONE;
}

int Parser::getNextToken()
{
	int nextPos = pos;
	int ch = (int)input[nextPos];
	
	while (true)
	{
		if (ch == ' ' || ch == '\t' || ch == '\r')
			ch = (int)input[nextPos++];
		else
			break;
	}

	return ch;
}


void Parser::match(int ch)
{
	if (token == ch)
		token = getToken();
	else
		return;
}

int Parser::expr()	//	<expr> => <bexp> { & <bexp> | '|' <bexp> } | !<expr> | true | false
{
	int result = 0;

	if (tokType == OPERATOR::NOT)
	{
		match('!');
		result = !(expr());
	}

	else if (tokType == OPERATOR::CHAR)
	{
		string s = input.substr(pos - 1, 4);
		
		if (s == "true" || s == "TRUE")
		{
			pos += 3;
			token = getToken();
			result = 1;
		}

		else if (s == "false" || s == "FALSE")
		{
			pos += 4;
			token = getToken();
			result = 0;
		}
	}

	else
	{
		result = bexp();

		while (tokType == OPERATOR::AND || tokType == OPERATOR::OR)
		{
			if (tokType == OPERATOR::AND)
			{
				token = getToken();
				result = result & bexp();
			}

			else if (tokType == OPERATOR::OR)
			{
				token = getToken();
				result = result | bexp();
			}
		}
	}

	return result;
}


int Parser::bexp()	//	<bexp> => <aexp> [ <relop> <aexp> ]
{
	int result = aexp();

	if (tokType == EQUAL || tokType == MORETHAN || tokType == LESSTHAN || tokType == NOT)	//	���� ��ū�� '=', '<', '>', '!'�� ���
	{
		tokType = (OPERATOR)relop();

		if (tokType == EQUAL)	//	==
		{
			token = getToken();
			match('=');
			result = (result == aexp());
		}

		else if (tokType == NOTEQUAL)	//	!=
		{
			token = getToken();
			match('=');
			result = (result != aexp());
		}

		else if (tokType == LESSTHAN)	//	<
		{
			match('<');
			result = (result < aexp());
		}

		else if (tokType == MORETHAN)	//	>
		{
			match('>');
			result = (result > aexp());
		}

		else if (tokType == ATMOST)	//	<=
		{
			token = getToken();
			match('=');
			result = (result <= aexp());
		}

		else if (tokType == ATLEAST)	//	>=
		{
			token = getToken();
			match('=');
			result = (result >= aexp());
		}
	}

	return result;
}

int Parser::relop()	//	<relop> => == | != | <|> | <= | >=
{
	OPERATOR result = tokType;
	int nextToken = getNextToken();

	if (isdigit(nextToken))	//	���� ��ū ���� ���� �Ǵ� ���ڶ�� ��ȣ�� �ϳ��� �����. ex) >, <, !
		return result;
	else
	{
		string s = "";
		s = s + (char)token + (char)nextToken;

		if (s == "==")
			result = EQUAL;
		
		else if (s == "!=")
			result = NOTEQUAL;
		
		else if (s == ">=")
			result = ATLEAST;
		
		else if (s == "<=")
			result = ATMOST;
	}

	return result;
}

int Parser::aexp()	//	<aexp> => <term> { + <term> | - <term> }
{
	int result = term();

	while (tokType== OPERATOR::ADD || tokType == OPERATOR::MIN)
	{
		if (tokType == OPERATOR::ADD)
		{
			match('+');
			result += term();
		}
		else if (tokType == OPERATOR::MIN)
		{
			match('-');
			result -= term();
		}
	}

	return result;
}


int Parser::term()	//	<term> => <factor> { * <factor> | / <factor> }
{
	// TODO: ���⿡ ���� �ڵ� �߰�.
	int result = factor();

	while (tokType == OPERATOR::MUL || tokType == OPERATOR::DIV)
	{
		if (tokType == OPERATOR::MUL)
		{
			match('*');
			result *= term();
		}
		else if (tokType == OPERATOR::DIV)
		{
			match('/');
			result /= term();
		}
	}

	return result;
}


int Parser::factor()	//	<factor> => [-] ( <number> | ( <aexp> ) )
{
	// TODO: ���⿡ ���� �ڵ� �߰�.
	int result = 0;

	if (tokType == MIN)
	{
		match('-');
		if (tokType == LPAREN)
		{
			match('(');
			result = -(aexp());
			match(')');
		}

		else if (tokType == DIGIT)
			result = -(number());
	}
	else
	{
		if (tokType == LPAREN)
		{
			match('(');
			result = aexp();
			match(')');
		}

		else if (tokType == DIGIT)
			result = number();
	}

	return result;
}

int Parser::number()	//	<number> => <digit> { <digit> }
{
	int result = 0;

	while (isdigit(token))
	{
		result = 10 * result + (token - '0');
		token = getToken();	//	���� ��ū�� �������� ���� ��ū���� �ѱ�
	}

	return result;
}

void Parser::print(int result)
{
	cout << endl;
	cout <<"\n\t= " << result << endl;
	cout << "-------------------------------------" << endl;
}

void Parser::parse()
{
	pos = 0;
	token = getToken();

	int result = expr();
	print(result);
}

void Parser::parse(string s)
{
	input = s;
	pos = 0;
	token = getToken();

	int result = expr();
	print(result);
}

